#!/bin/bash
cd /home/devops/home/personal/personalweb/disributor
nohup npm run start -- -p 3001 > logs/next.log 2>&1 &
echo $! > next.pid
echo "Next.js started on port 3001 (PID: $!)"
