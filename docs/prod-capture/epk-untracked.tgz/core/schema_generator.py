"""Custom Schema Generator to tolerate incompatible views."""
from drf_spectacular.generators import SchemaGenerator, reset_generator_stats
from drf_spectacular.openapi import AutoSchema as SpectacularAutoSchema
from drf_spectacular.plumbing import build_root_object, sanitize_result_object, normalize_result_object, process_webhooks
from drf_spectacular.settings import spectacular_settings
import logging
import weakref
import re
import posixpath

logger = logging.getLogger(__name__)


def _is_compatible_schema(schema):
    """Check if schema object is drf-spectacular's AutoSchema (not DRF's)."""
    if schema is None:
        return True  # Use default AutoSchema
    # Unwrap weakref proxy if needed
    if isinstance(schema, weakref.ProxyType):
        schema = schema.__wrapped__ if hasattr(schema, '__wrapped__') else schema
    # Check if it's drf-spectacular's AutoSchema specifically
    if isinstance(schema, SpectacularAutoSchema):
        return True
    # Check for duck-typed interface (get_operation method with correct signature)
    if hasattr(schema, 'get_operation'):
        import inspect
        try:
            sig = inspect.signature(schema.get_operation)
            # drf-spectacular's AutoSchema has 6 params (self, path, path_regex, path_prefix, method, registry)
            # DRF's AutoSchema has 3 params (self, path, method)
            if len(sig.parameters) >= 5:  # 5 params + self = 6
                return True
        except Exception:
            pass
    return False


# Views to skip (known incompatible with drf-spectacular 0.30.0)
SKIP_VIEW_MODULES = {
    'drf_spectacular.contrib.rest_auth',
    'drf_spectacular.views',
    'dj_rest_auth.views',
    'rest_framework_simplejwt.views',
}

SKIP_VIEW_NAMES = {
    'TokenRefreshView',
    'UserDetailsView',
    'SpectacularSwaggerView',
    'SpectacularAPIView',
    'Fixed',
}


class TolerantSchemaGenerator(SchemaGenerator):
    """Schema generator that skips views with incompatible schemas instead of crashing."""

    def get_schema(self, request=None, public=False):
        """Override get_schema to use our tolerant parse method."""
        reset_generator_stats()
        self._initialise_endpoints()
        paths = self._tolerant_parse(request, public)
        result = build_root_object(
            paths=paths,
            components=self.registry.build(spectacular_settings.APPEND_COMPONENTS),
            webhooks=process_webhooks(spectacular_settings.WEBHOOKS, self.registry),
            version=self.api_version or getattr(request, 'version', None),
        )
        for hook in spectacular_settings.POSTPROCESSING_HOOKS:
            result = hook(result=result, generator=self, request=request, public=public)

        return sanitize_result_object(normalize_result_object(result))

    def _tolerant_parse(self, request, public):
        """Parse endpoints, skipping incompatible views."""
        self._initialise_endpoints()
        all_paths = self._get_paths_and_endpoints()
        
        # Determine path_prefix (same logic as base class)
        if spectacular_settings.SCHEMA_PATH_PREFIX is None:
            non_trivial_prefix = len(set([view.__class__ for _, _, _, view in all_paths])) > 1
            if non_trivial_prefix:
                path_prefix = posixpath.commonpath([path for path, _, _, _ in all_paths])
                path_prefix = re.escape(path_prefix)
            else:
                path_prefix = '/'
        else:
            path_prefix = spectacular_settings.SCHEMA_PATH_PREFIX
        if not path_prefix.startswith('^'):
            path_prefix = '^' + path_prefix
        
        paths = {}
        for path, path_regex, method, view in all_paths:
            try:
                # Skip known incompatible views
                if self._should_skip_view(view):
                    logger.debug(f"Skipping known incompatible view: {view.__class__.__name__}")
                    continue
                
                # Skip views with explicitly incompatible schema
                if not _is_compatible_schema(view.schema):
                    logger.warning(f"Skipping schema generation for {view.__class__.__name__}: incompatible schema (using DRF AutoSchema)")
                    continue
                
                # Unwrap weakref proxy if needed
                schema = view.schema
                if isinstance(schema, weakref.ProxyType):
                    schema = schema.__wrapped__ if hasattr(schema, '__wrapped__') else schema
                
                # Set mock request for schema
                view.request = spectacular_settings.GET_MOCK_REQUEST(method, path, view, request)

                # Check permissions
                if not (public or self.has_view_permissions(path, method, view)):
                    continue

                # Get operation from schema
                operation = schema.get_operation(
                    path, path_regex, path_prefix, method, self.registry
                )

                # operation was manually removed via @extend_schema
                if not operation:
                    continue

                if spectacular_settings.SCHEMA_PATH_PREFIX_TRIM:
                    path = re.sub(pattern=path_prefix, repl='', string=path, flags=re.IGNORECASE)

                if spectacular_settings.SCHEMA_PATH_PREFIX_INSERT:
                    path = spectacular_settings.SCHEMA_PATH_PREFIX_INSERT + path

                if not path.startswith('/'):
                    path = '/' + path

                if spectacular_settings.CAMELIZE_NAMES:
                    from drf_spectacular.plumbing import camelize_operation
                    path, operation = camelize_operation(path, operation)

                paths.setdefault(path, {})
                paths[path][method.lower()] = operation
            except Exception as e:
                # Log and skip problematic views
                logger.warning(f"Skipping schema generation for {view.__class__.__name__}: {e}")
                continue
        return paths

    def _should_skip_view(self, view):
        """Check if view should be skipped."""
        view_class = view.__class__
        module = view_class.__module__
        name = view_class.__name__
        
        # Skip known incompatible modules
        for skip_module in SKIP_VIEW_MODULES:
            if module.startswith(skip_module):
                return True
        
        # Skip known incompatible view names
        if name in SKIP_VIEW_NAMES:
            return True
            
        return False

    def _get_paths_and_endpoints(self, request=None):
        """Override to filter out problematic paths early."""
        # Get all paths from parent (no request argument)
        all_paths = super()._get_paths_and_endpoints()
        
        # Filter out known problematic paths
        filtered = []
        for path, path_regex, method, view in all_paths:
            if not self._should_skip_view(view):
                filtered.append((path, path_regex, method, view))
        return filtered